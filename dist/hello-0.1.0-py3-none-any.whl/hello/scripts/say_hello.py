from colorama import Fore
def main():
    print(Fore.BLUE + "Hello!")


if __name__ == '__main__':
    main()